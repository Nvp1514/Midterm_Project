﻿' Program Name: Building Plans Conversion 
' Name: Natasha Patel 
' Date: 03/11/24
Imports System.IO
Imports System.Runtime.CompilerServices

Public Class Form1
    ' Constants for measurements conversion 
    Const I2M As Decimal = 0.0254
    Const M2I As Decimal = 39.37
    Dim count As Decimal
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtInput.Text = ""
        txtInput.Focus()
        lblResults.Text = ""
        lblFile.Text = ""
        txtFile.Text = ""
        radOne.Checked = True

    End Sub


    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        ' Variables for conversion and results 
        Dim userInput As Decimal
        Dim results As Decimal
        ' If statment to check if it's numeric 
        If IsNumeric(txtInput.Text) Then
            userInput = Convert.ToDecimal(txtInput.Text)
            ' if statement to check if it's positive 
            If userInput > 0 Then
                ' If statement to check which button is checked
                If radOne.Checked = True Then
                    results = userInput * I2M
                    lblResults.Text = Convert.ToString(userInput & " inches is " & results & " meters")


                ElseIf radTwo.Checked = True Then
                    results = userInput * M2I
                    lblResults.Text = Convert.ToString(userInput & " meters is " & results & " inches")
                End If
            Else
                MsgBox("The value you have entered is not positive")
                txtInput.Text = ""
            End If
        Else
            MsgBox("The value you have entered is not numeric")
            txtInput.Text = ""

        End If
    End Sub

    Private Sub btnClearR_Click(sender As Object, e As EventArgs) Handles btnClearR.Click
        ' Clear Test for clear results 
        txtInput.Text = ""
        txtInput.Focus()
        lblResults.Text = ""
        radOne.Checked = True
    End Sub

    Private Sub btnSaveR_Click(sender As Object, e As EventArgs) Handles btnSaveR.Click
        ' Save results to text box
        txtFile.AppendText(lblResults.Text)
        txtFile.AppendText(System.Environment.NewLine)
        count += 1
    End Sub

    Private Sub btnClearL_Click(sender As Object, e As EventArgs) Handles btnClearL.Click
        ' Clear the text box
        txtFile.Text = ""
    End Sub

    Private Sub btnSaveF_Click(sender As Object, e As EventArgs) Handles btnSaveF.Click
        Dim objWriter As New IO.StreamWriter("C:\Users\natas\OneDrive\Documents\midterm_project\measures.txt")
        ' OPen and checks file to write the text box to the file
        If IO.File.Exists("C:\Users\natas\OneDrive\Documents\midterm_project\measures.txt") Then
            objWriter.WriteLine(txtFile.Text)
            lblFile.Text = Convert.ToString("Saved " & count & " entries to file measures.txt")
        Else
            MsgBox("The file not available")
        End If
        ' Closes File
        objWriter.Close()
    End Sub
End Class
